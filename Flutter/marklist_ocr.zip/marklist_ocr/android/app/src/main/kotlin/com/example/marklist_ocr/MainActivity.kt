package com.example.marklist_ocr

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
