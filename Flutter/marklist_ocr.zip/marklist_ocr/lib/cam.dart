import 'package:camera/camera.dart';
import 'package:flutter/material.dart';
import 'builder.dart';
import 'package:path_provider/path_provider.dart';
import 'filerouting.dart';
import 'scanpage.dart';

class CamView extends StatefulWidget {
  CamView({
    Key key,
  }) : super(key: key);
  @override
  CamViewState createState() => CamViewState();
}

class CamViewState extends State<CamView> {
  CameraController controller;
  List<CameraDescription> cameras;
  int counter = 0;
  Bob worker = Bob();

  @override
  void initState() {
    super.initState();
    availableCameras().then((value) {
      cameras = value;
      controller = CameraController(cameras[0], ResolutionPreset.high);
      controller.initialize().then((_) {
        if (!mounted) {
          return;
        } else {
          setState(() {});
        }
      });
    });
  }

  @override
  void dispose() {
    controller?.dispose();
    super.dispose();
  }

  void choose() async {
    var filepicker = FileRoute();
    filepicker.pickImage().then((value) {
      worker.addimg(value);
    });
    counter++;
  }

  void cheese() async {
    if (!controller.value.isTakingPicture) {
      var dir = await getTemporaryDirectory();
      var place = dir.path + "/" + DateTime.now().toString();

      controller.takePicture(place).then((value) async {
        worker
            .addimg(
          place,
        )
            .then((_) {
          counter++;
        });
      });
    } else {
      return;
    }
  }

  void create() async {
    var sth = await worker.create();
    var pth = await getTemporaryDirectory();
    String paht = pth.path + "/" + sth + ".pdf";
    Navigator.push(
        context,
        MaterialPageRoute(
          builder: (context) => ListStage(
            bucket: 'gs://testocr-1100.appspot.com',
            name: sth,
            path: paht,
            size: counter + 1,
          ),
        ));
  }

  @override
  Widget build(BuildContext context) {
    if (!controller.value.isInitialized) {
      return Scaffold(
        appBar: AppBar(),
        body: Center(
          child: CircularProgressIndicator(),
        ),
      );
    } else {
      return Scaffold(
        appBar: AppBar(),
        body: Center(
            child: AspectRatio(
          aspectRatio: controller.value.aspectRatio,
          child: CameraPreview(controller),
        )),
        floatingActionButton: FloatingActionButton(
          onPressed: cheese,
          heroTag: 'out',
          child: Icon(Icons.camera_alt),
        ),
        floatingActionButtonLocation: FloatingActionButtonLocation.centerDocked,
        bottomNavigationBar: BottomAppBar(
            notchMargin: 4.0,
            shape: const CircularNotchedRectangle(),
            child: Row(
              children: [
                Flexible(
                    child: FlatButton(
                  onPressed: choose,
                  color: Colors.blue.shade100,
                  child: Text('Gallery'),
                )),
                Flexible(
                    child: FloatingActionButton(
                  onPressed: create,
                  child: Icon(Icons.thumb_up),
                  heroTag: 'south',
                )),
              ],
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
            )),
      );
    }
  }
}
