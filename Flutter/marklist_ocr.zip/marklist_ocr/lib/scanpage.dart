import 'package:flutter/material.dart';
import 'scanner.dart';

class ListStage extends StatefulWidget {
  final String name, bucket, path, function;
  final int size;
  ListStage(
      {Key key,
      @required this.name,
      @required this.bucket,
      @required this.path,
      this.function,
      @required this.size})
      : super(key: key);
  @override
  ListStageState createState() => ListStageState();
}

class ListStageState extends State<ListStage> {
  List<List<String>> extracts;
  String result;
  bool complete = false;
  @override
  void initState() {
    super.initState();
    cloudpart(
            path: widget.path,
            name: widget.name,
            len: widget.size,
            bucket: widget.bucket)
        .then((value) {
      setState(() {
        result = value;
        complete = true;
      });
    });
  }

  @override
  Widget build(BuildContext context) {
    if (!complete) {
      return Scaffold(
        appBar: AppBar(),
        body: Center(child: CircularProgressIndicator()),
      );
    } else {
      return Scaffold(
        appBar: AppBar(),
        body: Center(
            child: Container(
          child: Text(result),
        )),
      );
    }
  }
}
