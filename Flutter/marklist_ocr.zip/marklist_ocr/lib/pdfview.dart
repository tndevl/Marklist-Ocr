import 'dart:typed_data';
import 'package:native_pdf_renderer/native_pdf_renderer.dart';
import 'package:flutter/material.dart';
import 'builder.dart';
import 'cam.dart';

class PdfView {
  Uint8List img;
  int height;
  int width;
  String path;
  PdfView(@required this.path);
  String file;
  PdfDocument document;
  Future<Uint8List> start() async {
    final file = path;
    document = await PdfDocument.openFile(file);
    var val = load(1);
    return val;
  }

  Future<Uint8List> load(int pageNumber) async {
    var page = await document.getPage(pageNumber);
    height = page.height;
    width = page.width;
    page
        .render(
            width: page.width, height: page.height, format: PdfPageFormat.JPEG)
        .then((value) {
      img = value.bytes;
    });
    await page.close();
    return img;
  }
}

class PageViewer extends StatefulWidget {
  final String path;
  PageViewer({Key key, this.path}) : super(key: key);
  @override
  PageViewerState createState() => PageViewerState();
}

class PageViewerState extends State<PageViewer> {
  int i = 1;
  Uint8List image;
  PdfView page;
  String file;
  Bob bob = Bob();
  bool started = false;

  @override
  initState() {
    super.initState();
    page = PdfView(widget.path);
    page.start().then((value) {
      setState(() {
        image = value;
        started = true;
      });
    });
  }

  inc() {
    if (i < page.document.pagesCount) {
      i++;
      page.load(i).then((value) {
        setState(() {
          image = value;
        });
      });
    }
  }

  dec() {
    if (i > 1) {
      i--;
      page.load(i).then((value) {
        setState(() {
          image = value;
        });
      });
    }
  }

  instanciate() {
    bob.addpdf(image);
    Navigator.push(context, MaterialPageRoute(builder: (context) => CamView()));
  }

  @override
  Widget build(BuildContext context) {
    if (started == false) {
      return Scaffold(
        appBar: AppBar(),
        body: Center(child: CircularProgressIndicator()),
      );
    } else {
      return Scaffold(
        appBar: AppBar(),
        body: Stack(children: [Image.memory(image)]),
        floatingActionButton: Row(
          children: [
            Flexible(
                fit: FlexFit.loose,
                child: FloatingActionButton(
                  onPressed: dec,
                  child: Icon(Icons.arrow_left),
                  heroTag: 'bom',
                )),
            Flexible(
                fit: FlexFit.loose,
                child: FloatingActionButton(
                  onPressed: instanciate,
                  child: Icon(Icons.thumb_up),
                  heroTag: 'mob',
                )),
            Flexible(
                fit: FlexFit.loose,
                child: FloatingActionButton(
                  onPressed: inc,
                  child: Icon(Icons.arrow_right),
                  heroTag: 'nob',
                ))
          ],
          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
        ),
      );
    }
  }
}
