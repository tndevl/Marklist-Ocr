import 'package:flutter/material.dart';
import 'pdfview.dart';
import 'filerouting.dart';
import 'allow.dart';
import 'package:firebase_core/firebase_core.dart';

main() => runApp(MaterialApp(
      home: Home(),
    ));

class Home extends StatefulWidget {
  @override
  _HomeState createState() => _HomeState();
}

class _HomeState extends State<Home> {
  bool good;
  @override
  void initState() {
    Firebase.initializeApp();
    super.initState();
    Allow().start().then((value) {
      setState(() {
        good = value;
      });
    });
  }

  @override
  Widget build(BuildContext context) {
    if (bool != null) {
      return Scaffold(
        appBar: AppBar(),
        body: Container(),
        floatingActionButton: FloatingActionButton(onPressed: () async {
          var pick = FileRoute();
          pick.pickFile().then((value) {
            Navigator.push(
                context,
                MaterialPageRoute(
                    builder: (context) => PageViewer(
                          path: value,
                        )));
          });
        }),
      );
    } else {
      return Scaffold(
        appBar: AppBar(),
        body: Center(child: CircularProgressIndicator()),
      );
    }
  }
}

class HomePage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(),
      body: Container(),
      floatingActionButton: FloatingActionButton(onPressed: () async {
        var pick = FileRoute();
        pick.pickFile().then((value) {
          Navigator.push(
              context,
              MaterialPageRoute(
                  builder: (context) => PageViewer(
                        path: value,
                      )));
        });
      }),
    );
  }
}
