import 'package:http/http.dart' as http;
import 'package:firebase_storage/firebase_storage.dart';
import 'dart:io';
import 'dart:async';
import 'dart:convert';

Future<dynamic> cloudpart({
  String bucket,
  String name,
  String path,
  int len,
}) async {
  String directory;
  StorageReference storageReference =
      FirebaseStorage(storageBucket: bucket).ref().child(name);

  StorageUploadTask uploadTask = storageReference.putFile(File(path));
  final StreamSubscription<StorageTaskEvent> streamSubscription =
      uploadTask.events.listen((event) {
    print(event.type);
  }, onError: (error) {
    print(error.toString());
  }, cancelOnError: false);
  await uploadTask.onComplete;
  streamSubscription.cancel();
  sleep(const Duration(milliseconds: 50));
  Map<String, String> body = {'file': name};
  String func =
      'https://us-central1-testocr-1100.cloudfunctions.net/function-1';
  http.Response response = await http.post(func,
      headers: {"Content-Type": "application/json"}, body: json.encode(body));
  print(response.statusCode);
  print(response.body);

  String resultant = 'gs://receiver-bucket-test';
  StorageReference referer = FirebaseStorage(storageBucket: resultant)
      .ref()
      .child(resultant + "/" + name + "/" +"output-1-to" + len.toString() + ".json");
  var result = response.body;
  StorageFileDownloadTask dwnload = referer.writeToFile(File(directory));
  await dwnload.future;
  return result;
}
