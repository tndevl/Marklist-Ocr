import 'package:image_picker/image_picker.dart';
import 'package:file_picker/file_picker.dart';
import 'dart:io';

class FileRoute {
  final picker = ImagePicker();

  Future<String> pickImage() async {
    String path;
    var file = await picker.getImage(source: ImageSource.gallery);
    path = file.path;
    print(path);
    return path;
  }

  Future<String> pickFile() async {
    String path;
    File file = await FilePicker.getFile(
        type: FileType.custom, allowedExtensions: ['pdf']);
    path = file.path;
    print(path);
    return path;
  }

  retrieve(String image) async {
    var path;
    LostData data = await picker.getLostData();
    if (data.isEmpty != true) {
      path = data.file.path;
      return path;
    }
  }
}
