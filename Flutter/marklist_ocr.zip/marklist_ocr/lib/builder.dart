import 'dart:typed_data';
import 'dart:math';
import 'package:path_provider/path_provider.dart';
import 'package:pdf/pdf.dart';
import 'package:pdf/widgets.dart' as pw;
import 'dart:io';

class Bob {
  final pdf = pw.Document();

  static final Bob _singleton = Bob._internal();

  factory Bob() {
    return _singleton;
  }

  Bob._internal();
  String name;
  Directory tempdir;
  Future<String> create() async {
    tempdir = await getTemporaryDirectory();
    name = genName(10);
    var file = File(tempdir.path + "/" + name + ".pdf");
    file.writeAsBytes(pdf.save());
    return name;
  }

  String genName(int length) {
    var rand = new Random();
    var codeUnits = new List.generate(length, (index) {
      return rand.nextInt(25) + 96 + 1;
    });
    return String.fromCharCodes(codeUnits);
  }

  addpdf(Uint8List pug) async {
    PdfImage img = PdfImage.jpeg(
      pdf.document,
      image: pug,
    );
    pdf.addPage(pw.Page(build: (pw.Context context) {
      return pw.Center(
        child: pw.Image(img),
      ); // Center
    }));
  }

  addimg(String path) async {
    File(path).readAsBytes().then((value) {
      final image = PdfImage.jpeg(pdf.document, image: value);
      pdf.addPage(pw.Page(build: (pw.Context context) {
        return pw.Center(
          child: pw.Expanded(child: pw.Image(image)),
        ); // Center
      }));
    });
  }
}
