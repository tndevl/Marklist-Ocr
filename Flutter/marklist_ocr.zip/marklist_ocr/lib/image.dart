import 'dart:typed_data';

import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'pdfview.dart';

class PdfSEE extends StatefulWidget {
  final String path;
  PdfSEE({Key key, @required this.path}) : super(key: key);
  @override
  _PdfSEEState createState() => _PdfSEEState();
}

class _PdfSEEState extends State<PdfSEE> {
  bool started = false;
  Uint8List bytes;
  PdfView pdf;
  int i = 1;

  @override
  void initState() {
    super.initState();
    pdf = PdfView(widget.path);
    pdf.start().then((value) {
      setState(() {
        bytes = value;
        started = true;
      });
    });
  }

  update() async {
    i++;
    pdf.load(i).then((value) {
      setState(() {
        bytes = value;
      });
    });
  }

  @override
  Widget build(BuildContext context) {
    if (!started) {
      return Scaffold(
        appBar: AppBar(),
        body: Center(
          child: CircularProgressIndicator(),
        ),
      );
    } else {
      return Scaffold(
        appBar: AppBar(),
        body: Container(
          child: Image.memory(bytes),
        ),
        floatingActionButton: FloatingActionButton(
          onPressed: update,
        ),
      );
    }
  }
}
